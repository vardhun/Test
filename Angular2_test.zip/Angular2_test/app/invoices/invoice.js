"use strict";
var Invoice = (function () {
    function Invoice(name) {
        this.name = name;
    }
    return Invoice;
}());
exports.Invoice = Invoice;
//# sourceMappingURL=invoice.js.map